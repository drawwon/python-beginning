#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2017/4/23 10:29
# @Author  : Jeffrey
# @Site    : 
# @File    : 18-1.py
# @Software: PyCharm
from distutils.core import setup
setup(name='Hello',
      version='1.0',
      description='A simple example',
      author='Magnus lie hetlan',
      py_modules=['hello'])

